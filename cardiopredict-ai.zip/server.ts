import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // AI Health Interpretation Route
  app.post("/api/analyze-risk", async (req, res) => {
    try {
      const { data, riskScore } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;

      if (!apiKey) {
        return res.status(500).json({ error: "Gemini API key not configured" });
      }

      const ai = new GoogleGenAI({ apiKey });

      const prompt = `
        As a health information assistant, provide a brief, professional interpretation of the following patient data and cardiovascular risk score.
        Data: ${JSON.stringify(data)}
        Calculated Risk Score (0-100): ${riskScore}
        
        Guidelines:
        1. Be supportive but clinical.
        2. Explain which factors (BP, BMI, Age) are contributing most to their score based on common medical knowledge.
        3. Provide 3 specific, actionable lifestyle tips.
        4. Include a mandatory medical disclaimer at the end.
        5. Keep the total response under 250 words.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt
      });

      res.json({ analysis: response.text });
    } catch (error) {
      console.error("AI Analysis Error:", error);
      res.status(500).json({ error: "Failed to generate health insights" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
