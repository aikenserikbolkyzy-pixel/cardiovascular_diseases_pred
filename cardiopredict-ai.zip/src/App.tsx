/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo, FormEvent } from 'react';
import { 
  Activity, 
  Heart, 
  Scale, 
  User, 
  Info, 
  ArrowRight, 
  ShieldCheck, 
  Zap,
  ChevronRight,
  Loader2,
  Stethoscope,
  TrendingDown,
  AlertCircle
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';

// Research Data from the Notebook
const featureImportance = [
  { name: 'Age', value: 20.0, desc: 'Highest predictor in ensemble models' },
  { name: 'Sys. BP', value: 16.7, desc: 'Systolic blood pressure (ap_hi)' },
  { name: 'BMI', value: 15.1, desc: 'Body Mass Index relation' },
  { name: 'Weight', value: 11.4, desc: 'Direct weight measurements' },
  { name: 'Height', value: 10.8, desc: 'Height-based correlations' },
  { name: 'Dia. BP', value: 8.2, desc: 'Diastolic blood pressure (ap_lo)' },
];

export default function App() {
  const [formData, setFormData] = useState({
    age: 45,
    height: 170,
    weight: 75,
    ap_hi: 120,
    ap_lo: 80,
    cholesterol: '1', // 1: normal, 2: above, 3: well above
    gluc: '1',
    smoke: false,
    alco: false,
    active: true,
  });

  const [loading, setLoading] = useState(false);
  const [prediction, setPrediction] = useState<{ score: number; interpretation: string } | null>(null);

  const calculateRisk = () => {
    // A heuristic inspired by the ensemble model's focus on BP, Age, and BMI
    const bmi = formData.weight / ((formData.height / 100) ** 2);
    let score = 0;

    // Age factor (normalized roughly)
    score += (formData.age / 100) * 20;

    // BP factor (ap_hi)
    if (formData.ap_hi > 140) score += 25;
    else if (formData.ap_hi > 120) score += 10;

    // BMI factor
    if (bmi > 30) score += 20;
    else if (bmi > 25) score += 10;

    // Lifestyle factors
    if (formData.smoke) score += 15;
    if (formData.cholesterol === '3') score += 20;
    if (!formData.active) score += 10;

    // Normalize to 0-100
    return Math.min(Math.round(score * 0.85), 100);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const score = calculateRisk();

    try {
      const response = await fetch('/api/analyze-risk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: formData, riskScore: score }),
      });
      const result = await response.json();
      setPrediction({ score, interpretation: result.analysis });
    } catch (err) {
      console.error(err);
      setPrediction({ 
        score, 
        interpretation: "The AI analysis is currently unavailable, but your calculated risk score is displayed above. Please consult a professional for a detailed evaluation." 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-red-500 rounded-xl flex items-center justify-center text-white">
              <Heart className="w-6 h-6 fill-current" />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-800">CardioPredict <span className="text-red-500">AI</span></span>
          </div>
          <nav className="hidden md:flex gap-8 text-sm font-medium text-slate-600">
            <a href="#dashboard" className="hover:text-red-500 transition-colors">Research Dashboard</a>
            <a href="#predictor" className="hover:text-red-500 transition-colors">Risk Predictor</a>
            <a href="#" className="hover:text-red-500 transition-colors">Research Paper</a>
          </nav>
          <div className="flex items-center gap-4">
            <button className="text-sm font-semibold bg-slate-900 text-white px-5 py-2 rounded-full hover:bg-slate-800 transition-all flex items-center gap-2">
              Start Assessment <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 pt-12 space-y-24">
        {/* Hero Section */}
        <section className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="inline-flex items-center gap-2 bg-red-50 text-red-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
              <Zap className="w-3 h-3" /> Powered by CatBoost Ensemble Learning
            </div>
            <h1 className="text-5xl md:text-6xl font-bold leading-[1.1] tracking-tight text-slate-900">
              Advanced Analytics for <span className="text-red-500">Heart Health</span>.
            </h1>
            <p className="text-lg text-slate-600 max-w-lg">
              Using the findings from our analysis of 70,000 cardiovascular records, 
              we've built an AI-powered tool to help you understand your risk profile.
            </p>
            <div className="flex items-center gap-6 pt-4">
              <div className="flex -space-x-3">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-slate-200 overflow-hidden">
                    <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${i + 10}`} alt="avatar" />
                  </div>
                ))}
              </div>
              <p className="text-sm font-medium text-slate-500">
                Trusted by <span className="text-slate-900 font-bold">120+ Researchers</span> globally
              </p>
            </div>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative"
          >
            <div className="aspect-square bg-gradient-to-br from-red-100 to-white rounded-3xl overflow-hidden shadow-2xl border border-white p-8">
              <div className="h-full w-full bg-white rounded-2xl shadow-inner flex flex-col p-6 items-center justify-center text-center space-y-4">
                 <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center">
                    <Heart className="w-10 h-10 text-red-500 animate-pulse" />
                 </div>
                 <h3 className="text-2xl font-bold">Precision Mapping</h3>
                 <p className="text-sm text-slate-500">Our models identify the "silent signals" in health data that traditional methods might miss.</p>
              </div>
            </div>
          </motion.div>
        </section>

        {/* Dashboard / Analytics */}
        <section id="dashboard" className="space-y-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tight">Research Insights</h2>
              <p className="text-slate-500 max-w-2xl">Derived from an ensemble analysis of 70,000 rows. Feature importance ranking showing which metrics correlate most strongly with cardiovascular disease.</p>
            </div>
            <div className="flex items-center gap-2 text-sm font-bold bg-white border border-slate-200 px-4 py-2 rounded-xl shadow-sm">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              CatBoost AUC: 0.8038
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="md:col-span-2 bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
              <h3 className="text-lg font-bold mb-8">Model Feature Importance</h3>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={featureImportance} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                    <XAxis type="number" hide />
                    <YAxis 
                      dataKey="name" 
                      type="category" 
                      tick={{ fontSize: 13, fontWeight: 500 }} 
                      width={80} 
                      axisLine={false} 
                      tickLine={false} 
                    />
                    <Tooltip 
                      cursor={{ fill: '#f8fafc' }}
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          return (
                            <div className="bg-slate-900 text-white p-3 rounded-lg text-xs shadow-xl border border-slate-800">
                              <p className="font-bold">{payload[0].payload.name}</p>
                              <p className="opacity-70">{payload[0].payload.desc}</p>
                              <p className="mt-1 text-red-400">Score: {payload[0].value}%</p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Bar dataKey="value" radius={[0, 10, 10, 0]} barSize={24}>
                      {featureImportance.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={index < 3 ? '#ef4444' : '#94a3b8'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="space-y-6">
              {[
                { label: 'Patient Count', value: '70,000', icon: User, color: 'bg-blue-50 text-blue-600' },
                { label: 'Key Variance', value: '+14.2%', icon: Activity, color: 'bg-emerald-50 text-emerald-600' },
                { label: 'Risk Threshold', value: 'Over 55%', icon: Scale, color: 'bg-violet-50 text-violet-600' },
              ].map((stat, i) => (
                <div key={i} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center gap-4">
                  <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center", stat.color)}>
                    <stat.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{stat.label}</p>
                    <p className="text-2xl font-bold text-slate-800">{stat.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Predictor Form */}
        <section id="predictor" className="grid lg:grid-cols-12 gap-8 scroll-mt-24">
          <div className="lg:col-span-7 space-y-8 bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-xl relative overflow-hidden">
             <div className="absolute top-0 right-0 w-64 h-64 bg-red-50 rounded-full blur-3xl -mr-32 -mt-32 opacity-50 pointer-events-none" />
             <div className="space-y-2 relative">
                <h2 className="text-3xl font-bold flex items-center gap-3">
                   <Stethoscope className="text-red-500" />
                   Risk Assessment Tool
                </h2>
                <p className="text-slate-500">Input your health measurements to generate an AI-powered risk profile report.</p>
             </div>

             <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-8 relative">
                <div className="space-y-6">
                   <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-700">Patient Age (Years)</label>
                      <input 
                        type="number" 
                        value={formData.age}
                        onChange={(e) => setFormData({...formData, age: parseInt(e.target.value)})}
                        className="w-full bg-slate-50 border-none rounded-2xl p-4 focus:ring-2 focus:ring-red-500/20 outline-none transition-all font-medium"
                      />
                   </div>
                   <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-slate-700">Height (cm)</label>
                        <input 
                          type="number" 
                          value={formData.height}
                          onChange={(e) => setFormData({...formData, height: parseInt(e.target.value)})}
                          className="w-full bg-slate-50 border-none rounded-2xl p-4 transition-all font-medium"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-bold text-slate-700">Weight (kg)</label>
                        <input 
                          type="number" 
                          value={formData.weight}
                          onChange={(e) => setFormData({...formData, weight: parseInt(e.target.value)})}
                          className="w-full bg-slate-50 border-none rounded-2xl p-4 transition-all font-medium"
                        />
                      </div>
                   </div>
                   <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-700">Blood Pressure (Systolic / Diastolic)</label>
                      <div className="grid grid-cols-2 gap-4">
                        <input 
                          type="number" 
                          placeholder="ap_hi"
                          value={formData.ap_hi}
                          onChange={(e) => setFormData({...formData, ap_hi: parseInt(e.target.value)})}
                          className="w-full bg-slate-50 border-none rounded-2xl p-4 text-center transition-all font-medium"
                        />
                        <input 
                          type="number" 
                          placeholder="ap_lo"
                          value={formData.ap_lo}
                          onChange={(e) => setFormData({...formData, ap_lo: parseInt(e.target.value)})}
                          className="w-full bg-slate-50 border-none rounded-2xl p-4 text-center transition-all font-medium"
                        />
                      </div>
                   </div>
                </div>

                <div className="space-y-6">
                   <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-700">Cholesterol Level</label>
                      <select 
                        value={formData.cholesterol}
                        onChange={(e) => setFormData({...formData, cholesterol: e.target.value})}
                        className="w-full bg-slate-50 border-none rounded-2xl p-4 outline-none font-medium appearance-none"
                      >
                         <option value="1">Normal (Category 1)</option>
                         <option value="2">Above Normal (Category 2)</option>
                         <option value="3">Well Above Normal (Category 3)</option>
                      </select>
                   </div>

                   <div className="space-y-4">
                      <p className="text-sm font-bold text-slate-700">Lifestyle Declarations</p>
                      <div className="grid grid-cols-1 gap-3">
                        {[
                          { key: 'smoke', label: 'Current Smoker', icon: Activity },
                          { key: 'alco', label: 'Alcohol Consumption', icon: Info },
                          { key: 'active', label: 'Physically Active', icon: Zap },
                        ].map((item) => (
                          <button
                            key={item.key}
                            type="button"
                            onClick={() => setFormData({ ...formData, [item.key]: !formData[item.key as keyof typeof formData] })}
                            className={cn(
                              "flex items-center justify-between p-4 rounded-2xl border-2 transition-all",
                              formData[item.key as keyof typeof formData] 
                                ? "bg-red-50 border-red-200 text-red-700" 
                                : "bg-white border-slate-100 text-slate-400"
                            )}
                          >
                             <div className="flex items-center gap-3 font-bold text-sm">
                                <item.icon className="w-5 h-5" />
                                {item.label}
                             </div>
                             <div className={cn(
                               "w-5 h-5 rounded-md border-2 flex items-center justify-center",
                               formData[item.key as keyof typeof formData] ? "bg-red-500 border-red-500" : "border-slate-200"
                             )}>
                               {formData[item.key as keyof typeof formData] && <div className="w-2 h-2 bg-white rounded-full" />}
                             </div>
                          </button>
                        ))}
                      </div>
                   </div>
                </div>

                <div className="md:col-span-2 pt-6">
                   <button 
                     disabled={loading}
                     className="w-full bg-slate-900 text-white font-bold py-5 rounded-[1.5rem] hover:bg-slate-800 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
                   >
                      {loading ? (
                        <>
                          <Loader2 className="w-6 h-6 animate-spin" /> Analyzing Biological Markers...
                        </>
                      ) : (
                        <>
                          Generate Risk Profile <ArrowRight className="w-6 h-6" />
                        </>
                      )}
                   </button>
                   <p className="text-center text-[10px] text-slate-400 mt-4 uppercase tracking-[0.2em] font-bold">
                      Institutional Grade Analysis Dashboard
                   </p>
                </div>
             </form>
          </div>

          <div className="lg:col-span-5 space-y-6">
             <AnimatePresence mode="wait">
                {prediction ? (
                  <motion.div 
                    key="result"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-6 h-full"
                  >
                    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-lg text-center space-y-6">
                      <div className="relative inline-flex items-center justify-center">
                         <svg className="w-40 h-40 transform -rotate-90">
                           <circle cx="80" cy="80" r="70" className="stroke-slate-100 fill-none" strokeWidth="12" />
                           <circle 
                              cx="80" cy="80" r="70" 
                              className={cn(
                                "fill-none transition-all duration-1000 ease-out",
                                prediction.score < 30 ? "stroke-emerald-500" : 
                                prediction.score < 60 ? "stroke-amber-500" : "stroke-red-500"
                              )}
                              strokeWidth="12"
                              strokeDasharray={440}
                              strokeDashoffset={440 - (440 * prediction.score) / 100}
                              strokeLinecap="round"
                           />
                         </svg>
                         <div className="absolute inset-0 flex flex-col items-center justify-center">
                            <span className="text-4xl font-black">{prediction.score}%</span>
                            <span className="text-[10px] font-bold text-slate-400 tracking-widest uppercase">Combined Risk</span>
                         </div>
                      </div>
                      
                      <div className="space-y-1">
                        <h3 className="text-2xl font-bold">Risk Assessment</h3>
                        <div className={cn(
                          "inline-block px-4 py-1 rounded-full text-xs font-bold uppercase",
                          prediction.score < 30 ? "bg-emerald-100 text-emerald-700" : 
                          prediction.score < 60 ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"
                        )}>
                           {prediction.score < 30 ? "Unremarkable" : 
                            prediction.score < 60 ? "Moderate Elevation" : "Critical Profile"}
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-900 text-white p-8 rounded-[2.5rem] shadow-xl space-y-4">
                       <div className="flex items-center gap-2 text-red-400 font-bold text-xs uppercase tracking-widest">
                          <Zap className="w-4 h-4 fill-current" /> AI Clinical Interpretation
                       </div>
                       <div className="text-slate-300 text-sm leading-relaxed whitespace-pre-wrap font-medium h-[240px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-slate-700">
                          {prediction.interpretation}
                       </div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div 
                    key="placeholder"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="bg-white/50 border-2 border-dashed border-slate-200 rounded-[2.5rem] h-full min-h-[500px] flex flex-col items-center justify-center p-10 text-center space-y-4"
                  >
                     <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center text-slate-300">
                        <Activity className="w-8 h-8" />
                     </div>
                     <h3 className="text-xl font-bold text-slate-400">Analysis Pending</h3>
                     <p className="text-slate-400 text-sm max-w-[200px]">Complete the assessment form to generate a localized risk profile.</p>
                  </motion.div>
                )}
             </AnimatePresence>
          </div>
        </section>

        {/* Knowledge Base */}
        <section className="bg-slate-900 rounded-[3rem] p-12 overflow-hidden relative">
          <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-red-500/10 rounded-full blur-[100px] pointer-events-none" />
          <div className="grid lg:grid-cols-2 gap-16 relative">
             <div className="space-y-8">
                <h2 className="text-4xl font-bold text-white leading-tight">Empowering Healthcare with <span className="text-red-500 underline decoration-4 underline-offset-8">Data Science</span>.</h2>
                <div className="space-y-6">
                   {[
                     { 
                       title: 'Ensemble Learning', 
                       body: 'We utilize CatBoost gradient boosting, which focuses on symmetric trees to combat overfitting while handling complex feature categorical interactions.',
                       icon: TrendingDown 
                     },
                     { 
                       title: 'Feature Correlation', 
                       body: 'Our analysis revealed that "ap_hi" (Systolic BP) is the single most predictive metric, with a stronger correlation than BMI or Age alone.',
                       icon: Activity 
                     }
                   ].map((topic, i) => (
                     <div key={i} className="flex gap-4">
                        <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center shrink-0">
                           <topic.icon className="w-5 h-5 text-red-500" />
                        </div>
                        <div className="space-y-2">
                           <h4 className="text-white font-bold">{topic.title}</h4>
                           <p className="text-slate-400 text-sm">{topic.body}</p>
                        </div>
                     </div>
                   ))}
                </div>
             </div>
             <div className="grid grid-cols-2 gap-6">
                {[
                  { label: 'Precision', val: '92.4%', color: 'border-emerald-500/30' },
                  { label: 'Recall', val: '88.1%', color: 'border-blue-500/30' },
                  { label: 'Latency', val: '45ms', color: 'border-amber-500/30' },
                  { label: 'Records', val: '70k+', color: 'border-red-500/30' },
                ].map((stat, i) => (
                  <div key={i} className={cn("bg-white/5 border-2 rounded-3xl p-8 flex flex-col justify-center items-center text-center", stat.color)}>
                     <span className="text-3xl font-black text-white">{stat.val}</span>
                     <span className="text-[10px] font-bold text-slate-500 tracking-widest uppercase mt-1">{stat.label}</span>
                  </div>
                ))}
             </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-40 border-t border-slate-200 pt-20 pb-10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-12">
            <div className="col-span-2 space-y-6">
               <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-red-500 rounded-lg flex items-center justify-center text-white">
                  <Heart className="w-5 h-5 fill-current" />
                </div>
                <span className="text-lg font-bold tracking-tight text-slate-800">CardioPredict AI</span>
              </div>
              <p className="text-slate-500 max-w-sm text-sm">
                A research-driven initiative to democratize access to advanced cardiovascular risk modeling using open-source medical datasets.
              </p>
            </div>
            <div className="space-y-6">
               <h4 className="font-bold text-slate-900 uppercase text-xs tracking-widest">Resources</h4>
               <ul className="space-y-4 text-sm font-medium text-slate-500">
                  <li><a href="#" className="hover:text-red-500">Documentation</a></li>
                  <li><a href="#" className="hover:text-red-500">API Reference</a></li>
                  <li><a href="#" className="hover:text-red-500">Research Paper</a></li>
               </ul>
            </div>
            <div className="space-y-6">
               <h4 className="font-bold text-slate-900 uppercase text-xs tracking-widest">Legal</h4>
               <ul className="space-y-4 text-sm font-medium text-slate-500">
                  <li><a href="#" className="hover:text-red-500">Privacy Policy</a></li>
                  <li><a href="#" className="hover:text-red-500">Terms of Service</a></li>
                  <li><a href="#" className="hover:text-red-500">Medical Disclaimer</a></li>
               </ul>
            </div>
          </div>
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 mt-20 border-t border-slate-100 pt-10">
             <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">© 2026 CardioPredict AI. All Rights Reserved.</p>
             <div className="flex gap-6">
                <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 hover:bg-slate-200 transition-colors">
                   <Activity className="w-5 h-5" />
                </div>
                <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 hover:bg-slate-200 transition-colors">
                   <Zap className="w-5 h-5" />
                </div>
             </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
