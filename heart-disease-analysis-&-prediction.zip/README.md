# Heart Disease Analysis & Prediction

Этот проект посвящен анализу данных сердечно-сосудистых заболеваний и построению моделей машинного обучения для предсказания рисков.

## Структура проекта
- `notebooks/`: Jupyter Notebooks с исследовательским анализом данных (EDA) и обучением моделей.
- `app.py`: Приложение Streamlit для интерактивного предсказания.
- `requirements.txt`: Список зависимостей для запуска проекта.
- `data/`: Исходные и очищенные данные (CSV).

## Как запустить
1. Установите зависимости:
   ```bash
   pip install -r requirements.txt
   ```
2. Запустите Streamlit приложение:
   ```bash
   streamlit run app.py
   ```

## Используемые модели
- Random Forest
- Gradient Boosting (XGBoost, LightGBM, CatBoost)
- Logistic Regression
